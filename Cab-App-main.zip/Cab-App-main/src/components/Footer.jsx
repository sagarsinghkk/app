import "./Landing.css";
import React from "react";
import Car from "../assets/car.svg";

const Footer = () => {
    return (
        <footer className="fooat"><p className="foot">made with 🤎 by BINARY FUSION</p></footer>
    );
};

export default Footer;
